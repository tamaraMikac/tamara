import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
class calculator extends JFrame implements ActionListener {
    private static JFrame frame;
    private static JTextField text;
    String string, string1, string2;

    calculator() {
        string = string1 = string2 = ""; }

    public static void main(String args[]) {
        frame = new JFrame("Simple cal");
        frame.setSize(200,300);
        frame.setResizable(false);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        

        JButton b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, ba, bs, bd, bm, beq;

        b0 = new JButton("0");
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        b5 = new JButton("5");
        b6 = new JButton("6");
        b7 = new JButton("7");
        b8 = new JButton("8");
        b9 = new JButton("9");
        beq = new JButton("=");
        ba = new JButton("+");
        bs = new JButton("-");
        bd = new JButton("/");
        bm = new JButton("*");


        JPanel panel = new JPanel();
        text.setPreferredSize(new Dimension(100,30));
        frame.add(text,BorderLayout.NORTH);
        panel.setLayout(new GridLayout(4,4,2,1));

        bm.addActionListener(c);
        bd.addActionListener(c);
        bs.addActionListener(c);
        ba.addActionListener(c);
        b9.addActionListener(c);
        b8.addActionListener(c);
        b7.addActionListener(c);
        b6.addActionListener(c);
        b5.addActionListener(c);
        b4.addActionListener(c);
        b3.addActionListener(c);
        b2.addActionListener(c);
        b1.addActionListener(c);
        b0.addActionListener(c);
        beq.addActionListener(c);

        panel.add(b7);
        panel.add(b8);
        panel.add(b9);
        panel.add(ba);
        panel.add(b4);
        panel.add(b5);
        panel.add(b6);
        panel.add(bs);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(bm);
        panel.add(b0);
        panel.add(bd);
        panel.add(beq);

        frame.add(panel);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        if ((s.charAt(0) >= '0' && s.charAt(0) <= '9') || s.charAt(0) == '.') {
            if (!string1.equals(""))
                string2 = string2 + s;
            else
                string = string + s;

            text.setText(string + string1 + string2);
        }
        else if (s.charAt(0) == '=') {
            double result;

            if (string1.equals("+"))
                result = (Double.parseDouble(string) + Double.parseDouble(string2));
            else if (string1.equals("-"))
                result = (Double.parseDouble(string) - Double.parseDouble(string2));
            else if (string1.equals("/"))
                result = (Double.parseDouble(string) / Double.parseDouble(string2));
            else
                result = (Double.parseDouble(string) * Double.parseDouble(string2));

            text.setText(string + string1 + string2 + "=" + result);

            string = Double.toString(result);

            string1 = string2 = "";
        }
        else {
            if (string1.equals("") || string2.equals(""))
                string1 = s;

            else {
                double result;

                if (string1.equals("+"))
                    result = (Double.parseDouble(string) + Double.parseDouble(string2));
                else if (string1.equals("-"))
                    result = (Double.parseDouble(string) - Double.parseDouble(string2));
                else if (string1.equals("/"))
                    result = (Double.parseDouble(string) / Double.parseDouble(string2));
                else
                    result = (Double.parseDouble(string) * Double.parseDouble(string2));

                text.setText(string + string1 + string2 + "=" + result);

                string = Double.toString(result);

                string1 = s;
                string2 = "";
            }

            text.setText(string + string1 + string2);
        }
    }
}