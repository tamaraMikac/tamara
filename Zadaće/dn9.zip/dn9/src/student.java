public class student {
    private int vpisna_stevilka;
    private String ime;
    private String priimek;
    private Predmet[] index;

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getIme() {
        return ime;
    }

    public int getVpisna_stevilka() {
        return vpisna_stevilka;
    }

    public void setVpisna_stevilka(int vpisna_stevilka) {
        this.vpisna_stevilka = vpisna_stevilka;
    }

    public Predmet[] getIndex() {
        return index;
    }

    public void setIndex(Predmet[] index) {
        this.index = index;
    }

    public String getPriimek() {
        return priimek;
    }

    public void setPriimek(String priimek) {
        this.priimek = priimek;
    }

    public void dodaj_Predmet(Predmet p ) {
        Predmet[] Index = new Predmet[index.length + 1];
        for (int i = 0; i < index.length; i++) {
            for (int j = index.length; j < Index.length; j++) {
                if (index[i] == Index[j]) {
                    Index[j] = p;
                }
                index = Index;
            }
        }
    }

    public void Opravljeni() {
        System.out.println("Predmeti ki so opravljeni: ");
        for (int i = 0; i < index.length; i++) {
            if (index[i].isOpravil()) {
                System.out.println(index[i].getIme());
            }
        }
    }

    public void Ocena(int ocena, boolean opravil, String ime){
        for (int i = 0; i < index.length; i++){
            if(index[i].getIme() == ime){
                index[i].setOcena(ocena);
            }
        }
    }

    public boolean sveOpravljeno(boolean opravil){
        opravil = true;
        for (int i =0; i< index.length; i++){
            if (index[i].isOpravil()){
               opravil = false;
            }
        }
        return opravil;
    }
}
