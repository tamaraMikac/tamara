public class Predmet {
    private int id;
    private String ime;
    private boolean opravil;
    private int ocena;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public boolean isOpravil() {
        return opravil;
    }

    public void setOpravil(boolean opravil) {
        this.opravil = opravil;
    }
}