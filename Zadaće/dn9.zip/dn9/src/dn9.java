
import java.util.Scanner;

public class dn9 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String ime = scanner.nextLine();
        System.out.println("Ime: ");
        String priimek = scanner.nextLine();
        System.out.println("Priimek: ");
        int vs = scanner.nextInt();
        System.out.println("Vpisna stevilka: ");
        int predmeti = scanner.nextInt();
        Predmet[] index = new Predmet[predmeti];
        for (int i = 0; i < predmeti; i++) {
            String ime_predmeta = scanner.nextLine();
            System.out.println("Ime predmeta: ");
            String st = scanner.nextLine();
            System.out.println("Predmet ID: ");
            System.out.println("A je predmet - " + ime_predmeta + "opravljen ?");
            boolean opravil;
            System.out.println(" [da/ne] ");
        }
    }
}