import java.util.Scanner;

public class VDN {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] stevila = new int[n];

        for (int i = 0; i < stevila.length; i++) {
            stevila[i] = scanner.nextInt();
        }
        int elementi = 0;
        for (int i = 0; i < n; i++) {
            elementi++;
        }
        System.out.println("Stevilo elementov: " + elementi);

        //stevilo razlicnih elementov
        int razlicnie = 0;
        for (int i = 0; i < stevila.length; i++) {
            razlicnie = stevila[i];
            if (razlicnie != stevila[i]) {
                razlicnie++;
            }
        }
        System.out.println("Stevilo razlicnih elementov: " + razlicnie);

        //frekvenca pojavitev vsakega stevila
        int fr[] = new int[stevila.length];
        for (int i = 0; i < fr.length; i++) {
            fr[i] = 0;
        }
        double tabferkvenc[] = new double[stevila.length];
        for (int i = 0; i < stevila.length; i++) {
            tabferkvenc[i] = 0;
        }
        n = stevila.length;
        for (int i = 0; i < stevila.length; i++) {
            for (int j = 0; j < stevila.length; j++) {
                if (stevila[i] == stevila[j]) {
                    fr[i]++;
                }
            }
            tabferkvenc[i] = ((fr[i] * 100) / n);
        }
            boolean found;
            for (int i = 0; i < stevila.length; i++) {
                System.out.println("Stevilo " + stevila[i] + " se ponovi " + fr[i]
                        + " njena frekvenca je " + tabferkvenc[i] + "%");
        }



        //soda stevila
        int soda = 0;
        for (int i = 0; i < stevila.length; i++) {
            if (stevila[i] % 2 == 0) {
                System.out.println(stevila[i] + " ");
                soda++;
            }
        }
        System.out.println("Soda stevila: " + soda);

        //liha stevila
        int liha = 0;
        for (int i = 0; i < stevila.length; i++) {
            if (stevila[i] % 2 == 1) {
                System.out.println(stevila[i] + " ");
                liha++;
            }
        }
        System.out.println("Liha stevila: " + liha);

        //najvecje stevilo
    int max = stevila[0];
    for (int i =0; i<n; i++) {
        if(max < stevila[i]) {
            max = stevila[i];
        }
    }
        System.out.println("Največje število: " + max);

    //drugo najmanjse stevilo
        int min = stevila[1];
        for (int i =0; i<n; i++) {
            if (min > stevila[i]) {
                min = stevila[i];
            }

            System.out.println("Drugo najmanjse stevilo: " + min);
        }
        //povprecje vseh stevil
        int suma = 0;
        for(int i=0;i<stevila.length; i++) {
            suma = suma + stevila[i];
        }
        double povprecje = suma / stevila.length;
        System.out.println("Povprecje: " + povprecje);

        //standardna devijacija

    //vsoto vseh stevil
        int vsota = 0;
        for(int i=0; i<n; i++) {
            vsota = vsota + stevila[i];
        }
        System.out.println("Vsota vseh stevil: " + vsota);
    }
}

