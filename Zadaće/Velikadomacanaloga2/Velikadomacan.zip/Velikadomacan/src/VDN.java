import java.util.Scanner;

public class VDN {
    public static int palindrom(int num) {
        int palindrom1 = 1;
        int i = 0;
        int num1 = num;
        int num2 = 0;
        while (num != 0) {
            num = num / 10;
            num2++;
        }
        int b[] = new int[num2];
        while (num1 != 0) {
            b[i] = num1 % 10;
            num1 = num1 / 10;
            i++;
        }
        for (i = 0; i < num2 / 2; i++) {
            if (b[i] == b[num2 - 1 - i])
                continue;
            else {
                palindrom1 = 0;
                break;
            }
        }
        return palindrom1;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println("Vnesite " + n + " številk: ");
        int[] stevila = new int[n];
        for (int i = 0; i < n; i++) {
            stevila[i] = scanner.nextInt();
        }
        //stevilo elementov
        int[] elementi = new int[n];
        for (int i = 0; i < n; i++) {
            elementi[i] = stevila[i];
        }
        System.out.println("Stevilo elementov: " + n);

        //stevilo razlicnih elementov
        int razlicnie = 0;
        int j = 0;
        for (int i = 0; i < n; i++) {
            for (j = 0; j < i; j++)
                if (stevila[i] == stevila[j])
                    break;
            if (i == j) {
                razlicnie++;
            }
        }
        System.out.println("Stevilo razlicnih elementov: " + razlicnie);

        //frekvenca pojavitev vsakega stevila
        int fr[] = new int[stevila.length];
        for (int i = 0; i < fr.length; i++) {
            fr[i] = 0;
        }
        double tabferkvenc[] = new double[stevila.length];
        for (int i = 0; i < stevila.length; i++) {
            tabferkvenc[i] = 0;
        }
        n = stevila.length;
        for (int i = 0; i < stevila.length; i++) {
            for (j = 0; j < stevila.length; j++) {
                if (stevila[i] == stevila[j]) {
                    fr[i]++;
                }
            }
            tabferkvenc[i] = ((fr[i] * 100) / n);
        }
        boolean found;
        for (int i = 0; i < stevila.length; i++) {
            System.out.println("Stevilo " + stevila[i] + " se ponovi " + fr[i]
                    + " njena frekvenca je " + tabferkvenc[i] + "%");
        }

        //soda stevila
        int soda = 0;
        for (int i = 0; i < stevila.length; i++) {
            if (stevila[i] % 2 == 0) {
                System.out.println(stevila[i] + " ");
                soda++;
            }
        }
        System.out.println("Soda stevila: " + soda);

        //liha stevila
        int liha = 0;
        for (int i = 0; i < stevila.length; i++) {
            if (stevila[i] % 2 == 1) {
                System.out.println(stevila[i] + " ");
                liha++;
            }
        }
        System.out.println("Liha stevila: " + liha);

        //najvecje stevilo
        int max = stevila[0];
        for (int i = 0; i < n; i++) {
            if (max < stevila[i]) {
                max = stevila[i];
            }
        }
        System.out.println("Največje število: " + max);

        //drugo najmanjse stevilo
        int dns = 0;
        for (int i = 0; i < n; i++) {
            for (j = i + 1; j < n; j++)
                if (stevila[i] < stevila[j]) {
                    dns = stevila[i];
                    stevila[i] = stevila[j];
                    stevila[j] = dns;
                }
        }
        System.out.println("Drugo najmanjse stevilo: " + stevila[n - 2]);

        //povprecje vseh stevil
        int suma = 0;
        for (int i = 0; i < stevila.length; i++) {
            suma = suma + stevila[i];
        }
        double povprecje = suma / stevila.length;
        System.out.println("Povprecje: " + povprecje);

        //standardna devijacija
        int suma1 = 0;
        double sd = 0;
        for (int i = 0; i < stevila.length; i++) {
            suma1 = suma1 + stevila[i];
        }
        double povprecje1 = suma1 / (double) stevila.length;
        for (int counter = 0; counter < n; counter++) {
            sd = sd + Math.pow(stevila[counter] - povprecje1, 2);
        }
        double std = Math.sqrt(sd / (stevila.length));
        System.out.println("Standardna devijacija" + std);

        //mediano
        if (stevila.length % 2 == 0) {
            double mediano = ((double) (stevila[stevila[n] / 2]) + (double) (stevila[n / 2 - 1])) / (double) 2;
            System.out.println("Mediano: " + mediano);
        } else
            System.out.println("Mediano: " + stevila[n / 2]);


        //vsoto vseh stevil
        int vsota = 0;
        for (int i = 0; i < n; i++) {
            vsota = vsota + stevila[i];
        }
        System.out.println("Vsota vseh stevil:  " + vsota);

        //stevilo palindromov
        int pal = 0;
        for (int i = 0; i < n; i++)
            if (palindrom(stevila[i]) == 1) {
                pal++;
            }
        System.out.println("Stevilo palindromov: " + pal);


        //največje palindromno število, ki je manjše od največjega števila v polju in hkrati palindrom
        int maxp = stevila[0];

        int max_pal = maxp;
        boolean pal1 = false;

        for(int i = 1; i<n; i++)
            if(palindrom(stevila[i]) == 1 && stevila[i] != maxp) {
                pal1 = true;
                max_pal = stevila[i];
                break;
            }
        if(pal1)
            System.out.println("Največji palindrom je: " + max_pal);
        else
            System.out.println("Nima palindromov." );

            //Program naj na koncu še izpiše vsa števila, ki so v polju, ločena z vejicami, v obratnem vrstnem redu kot so bila vnešena
            for (int i = n - 1; i >= 0; i--)
                System.out.print(stevila[i] + ", ");
        }
    }



